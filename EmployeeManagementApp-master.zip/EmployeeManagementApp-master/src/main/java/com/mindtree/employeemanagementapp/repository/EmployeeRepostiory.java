package com.mindtree.employeemanagementapp.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.employeemanagementapp.entity.Employee;

@Repository
public interface EmployeeRepostiory extends JpaRepository<Employee, Integer> {

	Optional<Employee> findByName(String name);

}
