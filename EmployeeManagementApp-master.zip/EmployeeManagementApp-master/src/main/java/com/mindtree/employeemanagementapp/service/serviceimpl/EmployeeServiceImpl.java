package com.mindtree.employeemanagementapp.service.serviceimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.employeemanagementapp.entity.Employee;
import com.mindtree.employeemanagementapp.exception.service.EmployeeManagementAppServiceException;
import com.mindtree.employeemanagementapp.exception.service.custom.EmployeeAlreadyExistsException;
import com.mindtree.employeemanagementapp.exception.service.custom.EmployeeNotFoundExcption;
import com.mindtree.employeemanagementapp.exception.service.custom.EmployeesDataIsNotFoundExcption;
import com.mindtree.employeemanagementapp.repository.EmployeeRepostiory;
import com.mindtree.employeemanagementapp.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepostiory employeeRepostiory;

	public Employee addEmployeeData(Employee employee) throws EmployeeManagementAppServiceException {
		if (employeeRepostiory.findByName(employee.getName()).isPresent())
			throw new EmployeeAlreadyExistsException("Employee Alreday Exists");

		employeeRepostiory.save(employee);
		return employee;

	}

	public Set<Employee> getAllEmployee() throws EmployeeManagementAppServiceException {
		employeeRepostiory.findAll().stream().findAny()
				.orElseThrow(() -> new EmployeesDataIsNotFoundExcption("Employees Data Is Not Found"));

		return employeeRepostiory.findAll().stream().map(employee -> employee).collect(Collectors.toSet());

	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeManagementAppServiceException {
		Employee employee = employeeRepostiory.findById(id)
				.orElseThrow(() -> new EmployeeNotFoundExcption("Employee Not Found"));

		return employee;
	}

	public void writingInExcel() throws EmployeeManagementAppServiceException {
		List<Employee> employees = employeeRepostiory.findAll();

		try {

			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = workbook.createSheet("Employee Details");

			Row row;
			row = sheet.createRow(0);
			Cell cell01 = row.createCell(0);
			cell01.setCellValue("Serial NO.");
			Cell cell02 = row.createCell(1);
			cell02.setCellValue("Name");
			Cell cell03 = row.createCell(2);
			cell03.setCellValue("Salary");
			Cell cell04 = row.createCell(3);
			cell04.setCellValue("Mobile_Number");
			Cell cell05 = row.createCell(4);
			cell05.setCellValue("Designation");
			Cell cell06 = row.createCell(5);
			cell06.setCellValue("Designation");

			int rownum = 1;
			int serialNumber = 1;
			for (Employee employee2 : employees) {

				row = sheet.createRow(rownum++);
				Cell cell1 = row.createCell(0);
				cell1.setCellValue(serialNumber++);

				Cell cell2 = row.createCell(1);
				cell2.setCellValue(employee2.getName());

				Cell cell3 = row.createCell(2);
				cell3.setCellValue(employee2.getSalary());

				Cell cell4 = row.createCell(3);
				cell4.setCellValue(employee2.getMobileNumber());

				Cell cell5 = row.createCell(4);
				cell5.setCellValue(employee2.getDesignation());

				Cell cell6 = row.createCell(5);
				cell6.setCellValue(employee2.getPractices());

			}

			FileOutputStream fileOutputStream = new FileOutputStream(
					new File("C:\\Users\\m1057636\\Desktop\\EmployeeData.xlsx"));
			workbook.write(fileOutputStream);

			fileOutputStream.close();
			workbook.close();

		} catch (IOException e) {

			throw new EmployeeManagementAppServiceException(e.getMessage());

		}

	}

	public List<String> readingFromExcel() throws EmployeeManagementAppServiceException {
		try {

			FileInputStream fileInputStream = new FileInputStream("C:\\Users\\m1057636\\Desktop\\EmployeeData.xlsx");
			XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
			XSSFSheet sheet = workbook.getSheet("Employee Details");
			List<String> rowdata = new ArrayList<String>();

			Iterator<Row> rowIterator = sheet.iterator();

			while (rowIterator.hasNext()) {

				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.iterator();

				List<String> celldata = new ArrayList<String>();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					String s1 = cell.toString() + "    ";
					celldata.add(s1);

				}
				String s = celldata + "";
				rowdata.add(s);

			}

			workbook.close();
			fileInputStream.close();
			return rowdata;

		} catch (IOException e) {
			throw new EmployeeManagementAppServiceException(e.getMessage());
		}
	}

}
