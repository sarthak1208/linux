package com.mindtree.employeemanagementapp.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class EmployeeDTO {
	private int id;

	@NotBlank(message = "Employee Name Cannot Be Empty")
	private String name;

	@Min(value = 1000, message = "Employee Salary Must Above 1000")
	@Max(value = 100000, message = "Employee Salary Must Be Below 100000")
	private double salary;

	@Size(max = 10, message = "Mobile Number Must be 10 digits")
	private String mobileNumber;

	@NotBlank(message = "Employee Designation Cannot Be Empty")
	private String designation;

	@NotBlank(message = "Employee practices Cannot Be Blank")
	private String practices;

	public EmployeeDTO() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeDTO(int id, @NotBlank(message = "Employee Name Cannot Be Empty") String name,
			@Min(value = 1000, message = "Employee Salary Must Above 1000") @Max(value = 100000, message = "Employee Salary Must Be Below 100000") double salary,
			@Size(max = 10, message = "Mobile Number Must be 10 digits") String mobileNumber,
			@NotBlank(message = "Employee Designation Cannot Be Empty") String designation,
			@NotBlank(message = "Employee practices Cannot Be Blank") String practices) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.mobileNumber = mobileNumber;
		this.designation = designation;
		this.practices = practices;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getPractices() {
		return practices;
	}

	public void setPractices(String practices) {
		this.practices = practices;
	}

}
