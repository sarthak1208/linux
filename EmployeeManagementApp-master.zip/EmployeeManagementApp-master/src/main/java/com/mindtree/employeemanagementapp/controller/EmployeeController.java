package com.mindtree.employeemanagementapp.controller;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.employeemanagementapp.dto.EmployeeDTO;
import com.mindtree.employeemanagementapp.dto.ResponseBody;
import com.mindtree.employeemanagementapp.entity.Employee;
import com.mindtree.employeemanagementapp.exception.EmployeeManagementAppException;
import com.mindtree.employeemanagementapp.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private ModelMapper modelMapper;

	@PostMapping("/employee")
	public ResponseEntity<?> addEmployee(@Valid @RequestBody EmployeeDTO employee)
			throws EmployeeManagementAppException {

		return new ResponseEntity<ResponseBody<EmployeeDTO>>(new ResponseBody<EmployeeDTO>(modelMapper
				.map(employeeService.addEmployeeData(modelMapper.map(employee, Employee.class)), EmployeeDTO.class),
				null, "Employee Added Sucessfully", true), HttpStatus.OK);
	}

	@GetMapping("/employee")
	public ResponseEntity<?> getAllEmployee() throws EmployeeManagementAppException {

		return new ResponseEntity<ResponseBody<Set<EmployeeDTO>>>(new ResponseBody<Set<EmployeeDTO>>(
				modelMapper.map(employeeService.getAllEmployee(), new TypeToken<Set<EmployeeDTO>>() {
				}.getType()), null, "Employees Data Is Found", true), HttpStatus.OK);

	}

	@GetMapping("/employee/{id}")
	public ResponseEntity<?> getEmployeeByID(@PathVariable int id) throws EmployeeManagementAppException {

		return new ResponseEntity<ResponseBody<EmployeeDTO>>(
				new ResponseBody<EmployeeDTO>(modelMapper.map(employeeService.getEmployeeById(id), EmployeeDTO.class),
						null, "Employee Found", true),
				HttpStatus.OK);
	}

	@GetMapping("/writtinginexcel")
	public ResponseEntity<?> writtingIntoExcel() throws EmployeeManagementAppException {
		employeeService.writingInExcel();

		return new ResponseEntity<ResponseBody<Void>>(
				new ResponseBody<Void>(null, null, "Writting Into Excel Is Done", true), HttpStatus.OK);

	}

	@GetMapping("/readingfromexcel")
	public ResponseEntity<?> readingFromExcel() throws EmployeeManagementAppException {

		return new ResponseEntity<ResponseBody<List<String>>>(new ResponseBody<List<String>>(
				employeeService.readingFromExcel(), null, "Reading From Excel is Done", true), HttpStatus.OK);

	}

}
