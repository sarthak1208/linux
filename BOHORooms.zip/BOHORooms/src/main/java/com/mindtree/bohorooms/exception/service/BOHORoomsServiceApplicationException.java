package com.mindtree.bohorooms.exception.service;

import com.mindtree.bohorooms.exception.BOHORoomsApplicationException;

public class BOHORoomsServiceApplicationException extends BOHORoomsApplicationException {

	public BOHORoomsServiceApplicationException() {
		// TODO Auto-generated constructor stub
	}

	public BOHORoomsServiceApplicationException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BOHORoomsServiceApplicationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BOHORoomsServiceApplicationException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public BOHORoomsServiceApplicationException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
