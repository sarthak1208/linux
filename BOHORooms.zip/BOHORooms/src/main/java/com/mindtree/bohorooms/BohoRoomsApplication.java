package com.mindtree.bohorooms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BohoRoomsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BohoRoomsApplication.class, args);
	}

}
